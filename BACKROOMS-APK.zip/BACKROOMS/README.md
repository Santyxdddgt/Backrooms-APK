# BACKROOMS — APK Android (v1.2 · 100% local)

Versión Android del juego **BACKROOMS**. Todos los niveles, three.js, las
fuentes, los modelos 3D y los sonidos vienen DENTRO del APK: el juego
single-player funciona **completamente sin internet**.

La única parte online es el **modo multijugador**, que se conecta al servidor
global `https://backrooms-mp.onrender.com/` desde el botón del menú principal.

## Requisitos

| Herramienta | Versión |
|---|---|
| Android Studio | Ladybug (2024.2.1) o más nuevo |
| JDK | 17+ (incluido en Android Studio) |
| Android SDK | API 35 (lo descarga Android Studio solo) |
| Dispositivo/emulador | Android 7.0 (API 24) o superior |

Sin claves API, sin Firebase, sin Compose. Compila local o en GitHub Actions.

## Cómo compilar el APK

1. Descomprimí este zip.
2. **File → Open…** → carpeta `BACKROOMS`.
3. Esperá la sincronización de Gradle.
4. **Run ▶** con el teléfono conectado, o:
   - **Debug**: `Build → Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`
   - **Release**: `Build → Generate Signed App Bundle / APK → APK` (firmado con
     la keystore de debug, lista para instalar).
5. Instalá el `.apk` en el teléfono (habilitá "fuentes desconocidas" si lo pide).

> Consola: `./gradlew assembleDebug` (Linux/macOS) · `gradlew.bat assembleDebug` (Windows)

## Qué hay dentro (assets/)

```
app/src/main/assets/
├── index.html                  Nivel 0
├── level2.html                 Nivel 2
├── level3.html                 Nivel 3
├── level31.html                Nivel 31 (físicas cannon-es)
├── level31_postblackout.html   Nivel 31 · post-blackout
├── the-hub.html                THE HUB (nexo entre niveles)
├── poolrooms.html              Página de cortesía (el nivel todavía no existe
│                               ni en la web; evita un 404 tras la grieta-piscina)
└── vendor/                     ← TODAS las dependencias locales (~9 MB)
    ├── three-0.170.0/          three.module.js + GLTFLoader (Nivel 0 y 2)
    ├── three-0.160.0/          three.module.js + PointerLock/postprocessing (Nivel 31)
    ├── three-r128/             three.min.js (Nivel 3, 31-blackout, Hub)
    ├── cannon-es/              motor de física (Nivel 31)
    ├── fonts/                  Google Fonts mirror offline (8 familias, woff2)
    ├── media/                  Bacteria.glb + 2 sonidos de jumpscare
    └── error.html              Página "SIN SEÑAL" (sin internet en multiplayer)
```

Los HTML fueron reescritos para apuntar a estas copias locales — ya **no se
descarga nada** de jsdelivr, cdnjs, Google Fonts ni raw.githubusercontent.

## Multijugador (única parte online)

- En el **menú principal** hay un botón verde **"▶ MODO MULTIJUGADOR — ONLINE"**.
  Al tocarlo avisa que necesita internet y te lleva a
  `https://backrooms-mp.onrender.com/` **dentro de la app** (nunca abre el
  navegador). Ahí corre la versión online del juego, que se auto-conecta por
  WebSocket al servidor.
- Si no hay conexión, aparece la página local "SEÑAL PERDIDA" con botones
  **REINTENTAR** y **VOLVER AL JUEGO LOCAL**.
- El botón **ATRÁS** del teléfono te devuelve del servidor online al juego local.
- La pestaña "MODO MULTIJUGADOR" del juego local también acepta cualquier
  servidor `wss://` propio (sugiere `wss://backrooms-mp.onrender.com`).

## Cómo actualizar el juego

- **Solo HTML**: reemplazá los archivos en `assets/` manteniendo los enlaces a
  `./vendor/...` (mirá cualquier nivel actual como referencia).
- **Nivel nuevo**: copialo a `assets/` y asegurate de que sus dependencias
  estén en `vendor/` (three en la versión que use, fuentes, modelos, sonidos).

## Detalle técnico

- **WebView a pantalla completa**, inmersivo permanente, pantalla siempre
  encendida, rotación sin reinicio de partida, teclado ajustable para los
  inputs del multiplayer, doble ATRÁS para salir.
- **Origen virtual** `https://santyxdddgt.github.io/backrooms/` vía
  `WebViewAssetLoader` (handler local-first): origen seguro https para
  módulos ES/importmap, WebGL, WebAudio, localStorage unificado entre niveles
  y WebSocket. `ON_PAGES` da true → navegación relativa entre niveles,
  interceptada y servida desde el APK.
- **Hosts permitidos en el WebView**: el origen virtual del juego y
  `backrooms-mp.onrender.com`. Cualquier otro link cae al navegador externo.
- **Permisos**: `INTERNET` + `ACCESS_NETWORK_STATE` (solo para multiplayer;
  el single-player no genera tráfico).
- Recreación automática del WebView si muere el renderizador WebGL.

## Firma

- Debug y release firman con la keystore de debug autogenerada.
- Para Play Store: generá tu keystore con `keytool` y reemplazá el
  `signingConfig` en `app/build.gradle.kts`.

## Estructura del proyecto

```
BACKROOMS/
├── settings.gradle.kts · build.gradle.kts · gradle.properties
├── gradlew / gradlew.bat · gradle/wrapper/        (Gradle 8.11.1)
└── app/
    ├── build.gradle.kts      AGP 8.7.3 · Kotlin 2.0.21 · minSdk 24 · target 35
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/           ← juego completo + vendor (ver arriba)
        ├── java/com/backrooms/game/MainActivity.kt
        └── res/              ícono pasillo Nivel 0 (adaptivo + legacy), theme negro
```
