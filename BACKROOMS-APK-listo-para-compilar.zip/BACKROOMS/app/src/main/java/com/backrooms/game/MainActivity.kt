package com.backrooms.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

/**
 * BACKROOMS — contenedor nativo del juego (index.html en assets/).
 *
 * El juego se sirve con WebViewAssetLoader desde
 * https://appassets.androidplatform.net/assets/index.html en lugar de
 * file:///android_asset, porque necesita un ORIGEN SEGURO para:
 *  - módulos ES + importmap (three.js desde cdn.jsdelivr.net),
 *  - WebGL, localStorage (progreso/stats) y WebAudio,
 *  - WebSocket (multijugador) y descarga de .glb/.mp3 desde
 *    raw.githubusercontent.com.
 */
class MainActivity : Activity() {

    companion object {
        private const val TAG = "BackroomsWeb"
        private const val GAME_URL =
            "https://appassets.androidplatform.net/assets/index.html"
        private const val GAME_HOST = "appassets.androidplatform.net"
        private const val EXIT_GRACE_MS = 2500L
    }

    private lateinit var root: FrameLayout
    private var webView: WebView? = null
    private var backPressedAt = 0L

    // Vista del elemento fullscreen (botón ⛶ del juego).
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val assetLoader: WebViewAssetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(GAME_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(applicationContext))
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Que la pantalla no se apague durante la partida.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Edge-to-edge: el juego ocupa el 100% de la pantalla.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setBackgroundDrawableResource(android.R.color.black)
        if (Build.VERSION.SDK_INT >= 27) {
            // Dibujar bajo el notch en horizontal.
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)

        // Con barras ocultas el juego es fullscreen; cuando aparece el TECLADO
        // (nombre de sala multijugador, URL del servidor...) el contenedor se
        // encoge para que los inputs no queden tapados.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            v.setPadding(0, 0, 0, maxOf(ime, nav))
            insets
        }

        setupWebView()
        hideSystemBars()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        wv.setBackgroundColor(Color.BLACK)
        wv.overScrollMode = WebView.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true                       // localStorage: progreso, stats, config MP
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false        // sonidos del juego tras noclip
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_DEFAULT            // cachea el CDN para arranques más rápidos
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW  // servidores ws:// de prueba
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100                                  // ignora la escala de fuente del sistema
        }

        wv.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // El juego vive en nuestro dominio interno; cualquier otro
                // enlace (p. ej. THE HUB en github.io) se abre en el navegador.
                if (request.url.host == GAME_HOST) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onRenderProcessGone(
                view: WebView,
                detail: RenderProcessGoneDetail
            ): Boolean {
                // Si el renderizador WebGL muere (GPU), recreamos el WebView
                // en vez de matar la app.
                Log.e(TAG, "Render process gone (crash=${detail.didCrash()}); recreando WebView")
                exitCustomViewQuietly()
                root.removeAllViews()
                view.destroy()
                webView = null
                setupWebView()
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {

            override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                if (msg.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, "${msg.message()} — ${msg.sourceId()}:${msg.lineNumber()}")
                }
                return true
            }

            // ===== Fullscreen API del juego (botón ⛶) =====
            // En WebView, element.requestFullscreen() se canaliza por estos
            // callbacks: mostramos la vista del elemento cubriendo la pantalla.
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                root.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                hideSystemBars()
            }

            override fun onHideCustomView() {
                exitCustomViewQuietly()
            }
        }

        root.addView(wv)
        webView = wv
        wv.loadUrl(GAME_URL)
    }

    private fun exitCustomViewQuietly() {
        customView?.let { root.removeView(it) }
        customView = null
        try {
            customViewCallback?.onCustomViewHidden()
        } catch (_: Exception) {
        }
        customViewCallback = null
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Inmersivo permanente: si el usuario desliza para mostrar las barras,
        // se vuelven a ocultar al recuperar el foco.
        if (hasFocus) hideSystemBars()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Doble ATRÁS para salir, como en cualquier juego: evita cerrar la
        // partida por accidente en plena persecución.
        val now = System.currentTimeMillis()
        if (now - backPressedAt < EXIT_GRACE_MS) {
            super.onBackPressed()
        } else {
            backPressedAt = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        // Pausa JS/timers/RAF del juego mientras está en segundo plano.
        webView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onDestroy() {
        root.removeAllViews()
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
