plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.backrooms.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.backrooms.game"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Firma con la keystore DEBUG: permite generar e instalar un APK
            // release sin configurar nada. Para publicar en Play Store generá
            // tu propia keystore (ver README §Firma) y reemplazá esta línea.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = false
    }
}

dependencies {
    // Insets inmersivos (WindowCompat / WindowInsetsControllerCompat)
    implementation("androidx.core:core-ktx:1.15.0")
    // Sirve assets/ por https://appassets.androidplatform.net — origen seguro
    // para módulos ES (three.js), WebGL, localStorage y WebSocket del juego.
    implementation("androidx.webkit:webkit:1.12.1")
}
