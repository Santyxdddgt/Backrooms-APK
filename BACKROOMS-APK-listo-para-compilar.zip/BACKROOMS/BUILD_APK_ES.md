# Generar el APK de BACKROOMS

Este proyecto incluye el flujo `.github/workflows/build-apk.yml` para compilar un APK en GitHub Actions.

## Pasos

1. Crea un repositorio en GitHub.
2. Sube al repositorio el contenido de la carpeta `BACKROOMS` (incluyendo `.github/workflows/build-apk.yml`).
3. Abre la pestaña **Actions** del repositorio y selecciona **Build BACKROOMS APK**.
4. Pulsa **Run workflow** y vuelve a ejecutar el flujo en la rama principal si se solicita.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto **BACKROOMS-APK** en la sección **Artifacts**.
6. Descomprime ese artefacto: contiene `app-debug.apk`, que puedes transferir a tu teléfono e instalar.

El APK de depuración sirve para instalar y probar el juego. No es una compilación firmada con una clave propia para publicar en Google Play.

## Compilación local

Con Android Studio, abre esta carpeta como proyecto Gradle y ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El APK de depuración suele quedar en `app/build/outputs/apk/debug/app-debug.apk`.
