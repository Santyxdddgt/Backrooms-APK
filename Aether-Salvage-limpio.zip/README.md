# Aether Salvage — proyecto Android limpio

Este proyecto conserva el juego de `assets/index.html` extraído del APK y reemplaza la aplicación nativa generada por un wrapper Android mínimo.

## Qué se eliminó

- Firebase AI, Firebase App Check, Firebase Init Provider y reCAPTCHA.
- Google Play Services / `GoogleApiActivity`, permiso `READ_GSERVICES` y `ACCESS_NETWORK_STATE`.
- Compose, Room y el resto de bibliotecas nativas que no usa el juego.
- Permiso `DUMP`, depuración activada en la app, y copias de seguridad Android habilitadas.
- No incluye claves, `google-services.json`, archivos de Firebase ni SDK de analítica.

El HTML se mantuvo byte por byte: una búsqueda verificó que no contiene Firebase, Google Analytics, Google tag manager, App Check, Sentry SDK ni APIs de telemetría (`sendBeacon`, `fetch`, `XMLHttpRequest`, `WebSocket`). El único tráfico externo detectado es a `cdn.jsdelivr.net`, para cargar Three.js y `tune.js` que el juego utiliza. Por eso se conserva el permiso `INTERNET`; no se añadió ningún servicio de analítica.

## Compilar en GitHub Actions

Subí `Aether-Salvage-limpio.zip` a la raíz del repositorio `Santyxdddgt/Backrooms-APK`. El workflow `build-aether-salvage.yml` del repositorio lo extrae, compila `assembleRelease` y publica el APK como artifact.

Requisitos para compilar: JDK 17, Android SDK 35 y Gradle 8.11.1. El workflow los instala.

## Firma y actualizaciones

El `applicationId` se conserva como `com.aistudio.aethersalvage.qrxzmp` **únicamente para mantener la identidad de instalación del APK original**; no carga ni activa servicios de AI Studio. Para instalar como actualización sobre el APK antiguo, el nuevo debe firmarse con la misma clave privada que firmó ese APK.

El workflow acepta estos secretos del repositorio: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` y `ANDROID_KEY_PASSWORD`. También reconoce algunos nombres alternativos comunes. Si no encuentra una keystore, crea un APK de prueba con una clave debug temporal; ese archivo sirve para probar, pero Android no lo aceptará como actualización de una instalación firmada con otra clave.
