# Informe de limpieza

## APK original

El manifiesto original declaraba `INTERNET`, `ACCESS_NETWORK_STATE`, `com.google.android.providers.gsf.permission.READ_GSERVICES` y un permiso `DUMP`. También contenía los componentes `FirebaseInitProvider`, `ComponentDiscoveryService`, `GoogleApiActivity`, `PlayCoreDialogWrapperActivity` y varios registrars de Firebase AI, App Check y reCAPTCHA. La aplicación original estaba marcada `debuggable=true` y `allowBackup=true`.

## Proyecto resultante

- Solo declara `android.permission.INTERNET`, necesario para los módulos CDN que carga el juego.
- No declara Firebase, Google Play Services, App Check, reCAPTCHA, analytics, Compose ni dependencias externas para el runtime Android.
- Deshabilita las copias de seguridad automáticas y el tráfico HTTP en claro.
- El HTML del juego no se modifica para reducir el riesgo de romper mecánicas; el escaneo del archivo no encontró SDK ni endpoints de analítica.
- Conserva solo el `applicationId` original por compatibilidad de actualización. El paquete Java y el namespace se renombraron a `com.aethersalvage.game`. El `applicationId` no es telemetría, pero sí contiene el texto `aistudio` porque cambiarlo impediría actualizar la instalación existente.

## Limitación

No se puede deducir/recrear la clave privada de firma a partir del APK. Para que Android acepte una actualización encima de la app instalada, hay que usar la misma keystore/certificado de firma que se usó antes. El workflow intenta usar los secretos de firma configurados en GitHub; si no encuentra esos secretos, marca el build como prueba con firma debug.


## Comprobaciones automáticas del HTML

- `firebase/google analytics/aistudio markers`: 0 coincidencias.
- `telemetry APIs`: 0 coincidencias.
- URLs HTTP(S) vistas en el HTML:
  - `http://www.w3.org/2000/svg`
  - `https://cdn.jsdelivr.net`
  - `https://cdn.jsdelivr.net/gh/abbernie/tune@19930f99f4f345468ed19633b9805b6cb26e61b2/tune.js`
  - `https://cdn.jsdelivr.net/npm/three@0.186.0/+esm`
  - `https://cdn.jsdelivr.net/npm/three@0.186.0/build/three.core.js`
  - `https://cdn.jsdelivr.net/npm/three@0.186.0/build/three.module.min.js`
  - `https://cdn.jsdelivr.net/npm/three@0.186.0/examples/jsm/`
