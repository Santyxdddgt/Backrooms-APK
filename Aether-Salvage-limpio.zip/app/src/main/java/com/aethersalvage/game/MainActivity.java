package com.aethersalvage.game;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Minimal WebView shell for the local game. No analytics or Google SDKs. */
public final class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String GAME_URL = "https://appassets.androidplatform.net/assets/index.html";

    private FrameLayout root;
    private WebView gameView;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        enterImmersiveMode();
        createGameView(state);
    }

    private void createGameView(Bundle state) {
        gameView = new WebView(this);
        gameView.setBackgroundColor(Color.BLACK);
        gameView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gameView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // The game stores local progress here.
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        gameView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme())
                        && LOCAL_HOST.equalsIgnoreCase(uri.getHost())
                        && uri.getPath() != null
                        && uri.getPath().startsWith("/assets/")) {
                    String assetPath = uri.getPath().substring(1);
                    try {
                        InputStream stream = getAssets().open(assetPath);
                        String mimeType = assetPath.endsWith(".html") ? "text/html"
                                : assetPath.endsWith(".js") ? "text/javascript"
                                : assetPath.endsWith(".css") ? "text/css"
                                : assetPath.endsWith(".json") ? "application/json"
                                : "application/octet-stream";
                        return new WebResourceResponse(mimeType, "UTF-8", stream);
                    } catch (IOException error) {
                        byte[] message = "Local game asset not found".getBytes(StandardCharsets.UTF_8);
                        return new WebResourceResponse("text/plain", "UTF-8",
                                new ByteArrayInputStream(message));
                    }
                }
                // Return null for CDN requests so WebView handles them normally.
                return super.shouldInterceptRequest(view, request);
            }
        });

        root.addView(gameView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        if (state == null) {
            gameView.loadUrl(GAME_URL);
        } else {
            gameView.restoreState(state);
            if (gameView.getUrl() == null) gameView.loadUrl(GAME_URL);
        }
    }

    private void enterImmersiveMode() {
        Window window = getWindow();
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (gameView != null) gameView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) {
            root.removeView(gameView);
            gameView.loadUrl("about:blank");
            gameView.stopLoading();
            gameView.clearHistory();
            gameView.removeAllViews();
            gameView.destroy();
            gameView = null;
        }
        super.onDestroy();
    }
}
