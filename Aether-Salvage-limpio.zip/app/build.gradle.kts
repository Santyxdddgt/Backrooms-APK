plugins {
    id("com.android.application")
}

val releaseStorePath = System.getenv("ANDROID_KEYSTORE_PATH")
val releaseStorePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
val releaseKeyAlias = System.getenv("ANDROID_KEY_ALIAS")
val releaseKeyPassword = System.getenv("ANDROID_KEY_PASSWORD")

android {
    // Keep the app ID only for update compatibility; the code namespace is clean.
    namespace = "com.aethersalvage.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aistudio.aethersalvage.qrxzmp"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    signingConfigs {
        create("cleanRelease") {
            if (!releaseStorePath.isNullOrBlank()) {
                storeFile = file(releaseStorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            } else {
                // Fallback enables a test build; it cannot update an install
                // signed with another certificate.
                storeFile = file("${System.getProperty("user.home")}/.android/debug.keystore")
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("cleanRelease")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // Intentionally empty: no Firebase, Google Play Services, Compose or analytics SDK.
}
