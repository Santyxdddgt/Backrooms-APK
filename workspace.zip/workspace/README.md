# BACKROOMS — APK Android (v2.1 · 100% local + multijugador online en TODOS los niveles)

Versión Android del juego **BACKROOMS**. Todos los niveles (incluido el nuevo
**NIVEL 37 — POOLROOMS**), three.js, las fuentes, los modelos 3D y los
sonidos vienen DENTRO del APK: el juego single-player funciona
**completamente sin internet**.

La única parte online es el **modo multijugador**, que conecta por WebSocket
desde el propio juego local: `wss://backrooms-mp.onrender.com`.

## NOVEDADES v2.1 — Multijugador ONLINE en TODOS los niveles

- **[ARREGLO — POOLROOMS + NIVEL 2] BOTÓN «MODO MULTIJUGADOR — ONLINE»:** los
  Poolrooms y el Nivel 2 tenían el panel multijugador pero **sin botón para
  conectarse a internet** (el único camino era escribir a mano la URL del
  servidor). Ahora ambos niveles tienen el mismo botón que el Nivel 0:
  confirmación «⚠ SEÑAL GLOBAL» → **CONECTARME** → guarda
  `wss://backrooms-mp.onrender.com` → conecta y abre directamente la pestaña
  multijugador con la lista de servidores globales. Verificado contra el
  servidor real: conexión, creación de sala y sala visible en la lista.
- **[ADICIÓN] ONLINE EN TODOS LOS NIVELES:** los niveles que no tenían
  multijugador — **NIVEL 3 (Error 404), NIVEL 31 (Roller Rink), NIVEL 31
  POST-BLACKOUT y THE HUB** — ahora tienen el online **idéntico al Nivel 0**:
  botón ONLINE en la portada, pestaña ■ MODO MULTIJUGADOR (lista de servidores,
  crear sala con nombre/límite, unirse), **EMPEZAR** del admin con spawn en
  anillo, avatares remotos con color de sesión + visor + nametag flotante,
  chat global (tecla **T** o botón 💬), admin con **KICK**, salida con
  confirmación (✕ SALIR), reconexión por token y **sesión conservada al saltar
  de nivel**. Cada nivel con su paleta: neón en el 31, sangre en el 31-post,
  dorado en el 3 y el Hub.
- **[NUEVO] CLIENTE COMPARTIDO `vendor/mp-client.js`:** todo el sistema online
  vive en un único archivo autocontenido (UI + CSS + WebSocket + avatares +
  chat) que cada nivel integra con un adaptador mínimo. El Nivel 3 no tenía
  pestañas en la portada: el cliente le **crea** la fila INFORME / MODO
  MULTIJUGADOR. Servirá también para los próximos niveles (alcantarillas).
- **[MULTIJUGADOR] SELECTOR DE NIVEL DE SALA COMPLETO:** el admin puede mover
  la sala entera a cualquier nivel ya completado (ahora la lista incluye los
  7: Nivel 0, 2, 3, 31, 31-post, 37 y Hub) — todos los jugadores navegan
  automáticamente **conservando la sesión y el chat** (los parámetros `mp=1`
  y `mpserver=` viajan en la URL, así la sala sigue viva entre niveles aunque
  nunca se haya guardado el servidor en localStorage).
- **[MULTIJUGADOR] UNIRSE A PARTIDA EN CURSO:** si entras a una sala cuya
  partida ya empezó, entras directamente al juego (mismo comportamiento que
  el Nivel 0), y los jugadores que se desconectan quedan como
  «RECONECTANDO...» con plazo de gracia para volver por token.

## NOVEDADES v2.0 — Roller Rink neón · Portada 31-post limpia · Poolrooms en Stats

- **[NIVEL 31] PORTADA ROLLER RINK NEÓN:** la pantalla de título del Nivel 31
  normal (antes un simple panel centrado) ahora replica la estructura del
  Nivel 0: trackbar VHS, parpadeo de fluorescente, dos columnas (izquierda:
  etiqueta de cinta, título «NIVEL 31» con glitch y **fuente local Metal
  Mania**, subtítulo, línea de controles, «▶ ENTRAR A LA PISTA» + cinta DEV;
  derecha: tabs **■ INFORME / ■ ENTIDADES / ■ EQUIPO / ■ STATS**). Todo con
  paleta neón de pista de patinaje: magenta, cian y ámbar con *glows*, sobre
  violeta profundo. Los tabs muestran el informe del incidente, las
  entidades (El Entrenador, el Faceling, el DJ, los patinadores, el Apagón),
  el equipo (patines, tarjeta verde, basura, nostalgia) y la tabla de
  progreso guardado. Fuentes 100% locales (Metal Mania, VT323, Rubik Broken
  Fax — ya incluidas en `vendor/fonts/`). Responsive verificado: 1280×720,
  640×360 y 360×640 vertical.
- **[NIVEL 31 POST] PORTADA LIMPIA EN MÓVIL:** en la pantalla de título del
  post-blackout ya NO aparecen los botones de acción (CORRER, LINTERNA,
  RADAR, AGUA, joystick ni zonas táctiles) detrás del menú. Se ocultan hasta
  que arranca la partida (mismo patrón que el Nivel 0). Verificado en
  emulación móvil: 0 botones visibles en la portada; al entrar, todos
  disponibles.
- **[NIVEL 0] POOLROOMS EN STATS:** la pestaña ■ STATS de la portada del
  Nivel 0 ahora enumera los 6 niveles, incluido **NIVEL 37 — POOLROOMS**
  (antes faltaba). Además, corregido el ID del post-blackout
  ('31_postblackout' → '31_post'): la fila ahora marca ✓ PASADO con su mejor
  tiempo real al completar el nivel (antes quedaba eternamente PENDIENTE).
  Auditadas todas las enumeraciones: el HUB (grietas + stats) y el menú del
  31-post ya incluían los Poolrooms; el selector multijugador del Nivel 2
  tenía la entrada duplicada (limpiada).

## NOVEDADES v1.9 — Vuelo sin techo · Menú post-31 nivel-0 · Joystick completo

- **[DEV] VUELO SIN TECHO:** quitada la limitación de altura del vuelo con
  la CINTA PRIVILEGIADA. Antes cada nivel te capaba en su techo (Nivel 0:
  2,85 m · Nivel 2: 2,1 m · Poolrooms: 12 m · 31-post: 8 m). Ahora puedes
  subir MUY por encima del nivel entero y mirarlo desde el vacío (tope de
  seguridad lejano: 60 m en Poolrooms/31-post; sin tope en Nivel 0 y 2).
  Verificado en navegador: cámara sobrevolando el laberinto del Nivel 0,
  los túneles del 2, la pista a 10 m y los Poolrooms a 60 m exactos.
- **[POST-31] PORTADA CALCADA DEL NIVEL 0 (EN SANGRE):** la pantalla de
  título del 31 post-blackout ahora replica la estructura del Nivel 0:
  etiqueta de cinta, título «NIVEL 31» con glitch y tipografía Nosifer
  goteante, subtítulo, línea de controles (adaptada a táctil), botón
  «▶ TOCA PARA ENTRAR» + cinta DEV, trackbar VHS que baja, parpadeo de
  fluorescente, scanlines… y a la derecha los tabs **■ INFORME /
  ■ ENTIDADES / ■ EQUIPO / ■ STATS** con el mismo panel. Todo en paleta
  sangrienta (rojos/carmesí). El tab STATS muestra la tabla de progreso
  con ✔ PASADO / ◆ SOLO DEV / PENDIENTE y mejor tiempo. Solo el botón ▶
  entra (los tabs son clicables sin arrancar la partida). Responsive
  verificado: 1280×720, 640×360 y 360×640 vertical.
- **[POOLROOMS] JOYSTICK COMPLETO:** el círculo interior del joystick se
  cortaba en el borde del exterior al empujar al máximo (overflow:hidden
  heredado). Ahora SOBRESALE del círculo exterior hasta 17 px al llevar la
  palanca al tope (adelante = interior arriba del todo, saliendo del
  disco), como en un joystick físico. Las ondas acuáticas se recortan en
  su propio sub-contenedor para no romper el efecto.

## NOVEDADES v1.8 — Radio direccional · Menú post-31 limpio · DEV honesto

- **[RADIO] SOLO SUENA ARRIBA:** la música «LEASE» de los Poolrooms se oía en
  toda la sala. Ahora el volumen usa la **distancia real en 3D** (rango
  30 m → **7,5 m**) y una **compuerta de altura**: solo suena en la parte
  ALTA de la escalera de caracol (el balcón del destornillador y los últimos
  peldaños). En la sala de abajo —incluso justo debajo del balcón— la radio
  es muda. Sube la hélice y la música entra en fundido desde los últimos
  pasos.
- **[MENÚ POST-31] TÍTULO + BOTONES, SIN MURO DE TEXTO:** la pantalla de
  título del 31 post-blackout tenía tanta descripción que el «TOCA PARA
  ENTRAR» quedaba al borde y la CINTA DEV ni se veía. Ahora: título,
  subtítulo y los dos botones, siempre visibles (verificado hasta 640×360).
- **[POST-31] BOTONES DE SANGRE OFF por defecto:** «Activar botones
  detallados sangre» ahora nace **desactivado** (botones simples). Migración
  única para saves viejos: se fuerza OFF una sola vez salvo elección
  explícita del jugador (el toggle recuerda tu elección en `dbgChosen`).
- **[⚙] EL ENGRANE SOLO EXISTE EN DEV:** en level31, 31-post y 37-2 el botón
  ⚙ salía SIEMPRE (pantalla de título incluida) porque la clase `.hidden`
  no estaba definida en esos archivos. Arreglado: el ⚙ aparece únicamente
  tras insertar la CINTA PRIVILEGIADA. En el 37-2 la cinta es un botón
  verde «▶ INSERTAR CINTA PRIVILEGIADA — DEV» que revela el selector.
- **[DEV] PASAR EN DEV ≠ PASAR DE VERDAD:** completar un nivel con la cinta
  puesta se registra en `levelsCompletedDev` (lista separada): **no** entra
  en `levelsCompleted`, **no** suma victorias, **no** guarda récords y
  **no desbloquea grietas** (la puerta «?» del Hub exige el pase NORMAL del
  31-post). El Hub lo muestra como **«◆ SOLO DEV»** en stats y en el menú
  de grietas. Cubre: nivel 0, 2, 3, 31, 31-post y 37; el DEV de sala del
  multijugador y el huevo `?dev` también cuentan como DEV.
- **[DEV] AVISO ÚNICO:** la primera vez que activas la cinta (una sola vez
  en la vida del save) aparece un aviso no bloqueante: «un nivel pasado en
  DEV se registra como PASADO EN DEV… si es tu primera vez, pásatelo
  NORMAL para que cuente». No vuelve a molestar.
- **[FIX HUB] ENTRAR ≠ PASAR:** el Hub mandaba `&level=` al entrar en una
  grieta y el Nivel 0 quedaba COMPLETADO con solo entrar desde el Hub. El
  parámetro se eliminó: entrar no marca nada (los niveles se marcan al
  ganarse, en su propia página).

## NOVEDADES v1.7 — Hub oculto · Radio arreglada · DEV en todos los niveles

- **[HUB-OCULTO] GRIETA DE POOLROOMS SELLADA hasta el 31 post-blackout:**
  en The Hub, la grieta del Nivel 37 ahora nace como una **PUERTA «?»
  SELLADA** (negra, «?» blanco parpadeante, cartel «GRIETA SELLADA»):
  no suena, no se cruza y no revela su tema. Al completarse el
  **31 POST-BLACKOUT** (entrar en su grieta-piscina hacia Poolrooms)
  vuelve como la grieta aqua de siempre. En el menú GRIETAS aparece
  como «◆ ¿?????» · **SELLADA**.
- **[HUB-OCULTO] Sistema genérico de prerequisitos:** cualquier grieta que
  se añada al Hub en el futuro declara su `prereq` en `RIFT_DEFS` y nace
  sellada como puerta «?» hasta que el jugador se pase el nivel anterior.
  El TP del panel DEV del Hub avisa qué grieta está sellada y por qué.
- **FIX RADIO (Poolrooms):** la radio «LEASE» estaba FLOTANDO fuera del
  balcón (en `cx-1.15` cuando la plataforma solo cubría `cx+0.2→cx+1.5`):
  se le añadió el **ALA OESTE del balcón** y ahora descansa en el suelo,
  a ~1.6 m del destornillador. Y **el silencio era un bug**: en modo
  WebAudio el elemento `<audio>` quedaba con `volume=0` y el
  `MediaElementSource` entregaba silencio al grafo (por eso no sonaba ni
  a un metro). Ahora el elemento queda a `volume=1` y el gain del grafo
  manda en la distancia; además el reintento de autoplay reanuda el
  AudioContext si quedó suspendido.
- **CINTA PRIVILEGIADA en TODOS los niveles:** el modo DEV llega a
  **level3** (inmortal frente a Ella, vuelo, TP, cierre directo al Hub),
  **level31** (vuelo sobre el cuerpo físico, patines y salto directo al
  blackout → 31 post-blackout), **level31_postblackout** (inmortal frente
  a la Entidad 15, TP a la grieta-piscina, 5 esquirlas y cierre real),
  **poolrooms** (vuelo, ×2, radio forzada a volumen pleno, TP a los tres
  objetivos y cierre del 37) y **The Hub** (acelerón y TP a cada grieta,
  selladas incluidas). En el 37.2, un selector de nivel DEV. Nivel 0 y 2
  ya la tenían.

## NOVEDADES v1.6 — Radio LEASE · HUD aqua · fix de lag del Hub

- **RADIO «LEASE» (Takeshi Abo)**: en el balcón superior de la escalera de
  caracol, **a 2 m del destornillador**, hay ahora una radio celeste con
  frente blanco (rejilla, perillas y antena) con un halo suave y un LED que
  parpadea. Reproduce en bucle el tema extendido de LEASE (16:45, incluido
  en el APK en `vendor/media/LEASE-radio.mp3`, 96 kbps). **El volumen cae
  con la distancia** (silencio total a ~30 m) y además se va "apagando"
  (filtro pasabajos): lejos suena como a través de paredes. Cerca muestra
  el prompt `♪ RADIO — «LEASE» · MÁS CERCA = MÁS FUERTE`.
- **HUD táctil aqua (Poolrooms)**: joystick y botones RADAR/USAR/PAUSA/CHAT
  **re-rediseñados como vidrio de agua translúcido** — anillos de onda y
  causticas animadas, borde y brillo aqua. Las animaciones usan SOLO
  `transform` (compositor de GPU), medido en navegador: **coste estático
  0.0 % y coste animado ~2 % incluso en render por software**; en un móvil
  real con GPU es practicamente gratis.
- **FIX DE LAG — THE HUB**: el bucle animaba las **5 grietas** (todas sus
  decos, fases, parpadeos y shaders) cada frame sin importar la distancia,
  y el HUD reescribía el DOM ~60 veces por segundo (texto de salto, barra
  de aguante, indicadores). Ahora:
  - **LOD por distancia**: a más de 26 m una grieta queda estática (base de
    luz fija); al acercarse vuelve a animar igual que antes.
  - **HUD cacheado a 10 Hz**: escrituras DOM solo cuando el valor cambia
    (medido: de ~180 escrituras/3 s a **0** en reposo).
  - **Techo de resolución** 1.25× en móviles (el Hub pinta 2 pasadas
    fullscreen; el grano VHS disimula la diferencia) → ~30 % menos carga
    de GPU en pantallas 2x/3x.

## NOVEDADES v1.5 — Stats fijados + Portal Poolrooms + Alcantarillas

- **Stats (fix):** el **NIVEL 37 — POOLROOMS** ahora tiene su fila en la
  tabla de Stats del HUB (antes no existía, aunque el juego lo marcaba como
  completado). En la tabla de stats de poolrooms, la fila POST-BLACKOUT
  ahora lee el id correcto (`31_post`) y refleja el estado real.
- **HUB (nuevo):** grieta **POOLROOMS — NIVEL 37** (aqua, con azulejos,
  agua animada y aro de pileta) para volver al Nivel 37 sin repetir el
  post-blackout. En el menú GRIETAS suma la quinta entrada.
- **HUB (nuevo):** **PUERTA DE LAS ALCANTARILLAS** — puerta negra con
  "?" blanco que parpadea; entrás caminando (sin salto) y caés en el
  sector `level37-2.html` (SECTOR NO CONSTRUIDO).
- **Esquirlas del HUB:** al recogerlas avisan "ESTO SERVIRÁ PARA
  DESPUÉS…"; si llegás al post-blackout con las 3 del HUB, te felicita
  al arrancar ("LAS 3 ESQUIRLAS DEL HUB TE ACOMPAÑAN") y el HUD ya
  arranca en 3/5.


## NOVEDADES v1.4 — Nivel 37: POOLROOMS

- **NIVEL 37 — POOLROOMS**: complejo infinito de salas y corredores
  inundados, con azulejos procedurales, agua con cáusticas, ojos de buey y
  luz de tarde. Objetivo: destornillador en la escalera de caracol → tapa de
  drenaje → descenso al 37.2. Se llega desde la **grieta-piscina del Nivel 31
  (post-blackout)**. Todo corre local (three.js 0.186 dentro del APK).
- **NIVEL 37.2 — ALCANTARILLAS**: sector todavía no construido (página de
  cortesía con retorno al HUB y al Nivel 0, también local).
- **MULTIJUGADOR en Poolrooms**: el nivel trae su propia pestaña MP
  (salas, chat, jugadores remotos, salto de nivel del admin). Compatible con
  el servidor `backrooms-mp.onrender.com` (v2). El admin puede mover la sala
  al **NIVEL 37**; los clientes del APK navegan a `poolrooms.html` local.
- **Selector de niveles MP (Nivel 2)**: ahora ofrece también NIVEL 37 —
  POOLROOMS (se desbloquea al completarlo, como los demás).

## NOVEDADES v1.3 — Multijugador (MP v2)

- **CHAT GLOBAL**: tecla `T` (o botón 💬 en móvil) abre el chat. Cada mensaje
  se muestra como `NOMBRE: mensaje` con el color fijo del jugador. **Sin
  censura ni filtros**: el texto viaja y se muestra tal cual lo escribiste.
  Funciona en el menú, en partida y en el nivel 2.
- **COLOR FIJO POR JUGADOR**: cada jugador recibe un color distinto al entrar
  a la sala (visor del casco + insignia del pecho + nametag + nombre en el
  chat). El color se mantiene toda la sesión, incluso al reconectar.
- **JUGADORES CON CABEZA**: los avatares remotos ahora tienen casco con visor
  luminoso del color del jugador (antes iban decapitados). El jugador local
  no ve su propia cabeza (cámara en primera persona), pero sí su insignia.
- **ESQUIRLAS Y GRIETA COMPARTIDAS**: la sala genera una semilla en el
  servidor → todos ven las esquirlas y la grieta en las MISMAS posiciones.
  Cuando alguien recoge una esquirla, desaparece para todos y el contador
  del HUD pasa a ser el GLOBAL de la sala (el radar también apunta igual).
- **ENEMIGOS COMPARTIDOS**: el admin de la sala (host) simula Bacteria,
  Sabueso y El Presente contra **el jugador MÁS CERCANO** (local o remoto) y
  difunde sus posiciones a 10 Hz; el resto las ve moverse en tiempo real.
  Si te atrapan, tu secuencia de muerte/jumpscare es la tuya, y todos ven
  el aviso en el chat.
- **GRIETA GRUPAL**: basta que **UN** jugador junte las 5 esquirlas y entre
  en la grieta → **TODA la sala se teletransporta al nivel 2** con las stats
  de ese jugador (noclip grupal, cada uno con su cinemática).

> ⚠ **Importante — servidor**: estas mejoras requieren el `server.js` de la
> versión MP v2 en `backrooms-mp.onrender.com`. Redesplegá tu servidor con el
> contenido de `BACKROOMS-MP-SERVER.zip` (server.js + index.html + level2.html
> web). Con el servidor viejo la app sigue funcionando, pero en modo
> compatible: sin chat, esquirlas/enemigos locales y grieta individual.

## Requisitos

| Herramienta | Versión |
|---|---|
| Android Studio | Ladybug (2024.2.1) o más nuevo |
| JDK | 17+ (incluido en Android Studio) |
| Android SDK | API 35 (lo descarga Android Studio solo) |
| Dispositivo/emulador | Android 7.0 (API 24) o superior |

Sin claves API, sin Firebase, sin Compose. Compila local o en GitHub Actions.

## Cómo compilar el APK

1. Descomprimí este zip.
2. **File → Open…** → carpeta `BACKROOMS`.
3. Esperá la sincronización de Gradle.
4. **Run ▶** con el teléfono conectado, o:
   - **Debug**: `Build → Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`
   - **Release**: `Build → Generate Signed App Bundle / APK → APK` (firmado con
     la keystore de debug, lista para instalar).
5. Instalá el `.apk` en el teléfono (habilitá "fuentes desconocidas" si lo pide).

> Consola: `./gradlew assembleDebug` (Linux/macOS) · `gradlew.bat assembleDebug` (Windows)

### Compilar con GitHub Actions (sin PC)

El proyecto ya incluye el workflow `.github/workflows/android.yml`:

1. Subí la carpeta `BACKROOMS` a un repo de GitHub.
2. Pestaña **Actions** → workflow **Build APK (debug + release)** → **Run workflow**.
3. Al terminar, descargá el artefacto `BACKROOMS-debug-apk` (o `release`).

## Qué hay dentro (assets/)

```
app/src/main/assets/
├── index.html                  Nivel 0 (+ todo el cliente MP v2)
├── level2.html                 Nivel 2 (+ chat/colores/cabezas MP v2 + Nivel 37 en MP)
├── level3.html                 Nivel 3
├── level31.html                Nivel 31 (físicas cannon-es)
├── level31_postblackout.html   Nivel 31 · post-blackout (grieta-piscina → Poolrooms)
├── the-hub.html                THE HUB (nexo entre niveles)
├── poolrooms.html              NIVEL 37 — POOLROOMS (juego completo, offline)
├── level37-2.html              NIVEL 37.2 — ALCANTARILLAS (sector no construido)
└── vendor/                     ← TODAS las dependencias locales (~23 MB)
    ├── three-0.186.0/          three.module.js + three.core.js + postprocessing (Poolrooms)
    ├── three-0.170.0/          three.module.js + GLTFLoader (Nivel 0 y 2)
    ├── three-0.160.0/          three.module.js + PointerLock/postprocessing (Nivel 31)
    ├── three-r128/             three.min.js (Nivel 3, 31-blackout, Hub)
    ├── cannon-es/              motor de física (Nivel 31)
    ├── fonts/                  Google Fonts mirror offline (8 familias, woff2)
    ├── media/                  Bacteria.glb + 2 sonidos de jumpscare + LEASE-radio.mp3 (12 MB)
    └── error.html              Página "SIN SEÑAL" (sin internet en multiplayer)
```

Los HTML fueron reescritos para apuntar a estas copias locales — ya **no se
descarga nada** de jsdelivr, cdnjs, Google Fonts ni raw.githubusercontent.

## Multijugador (única parte online)

- En el **menú principal** hay un botón verde **"▶ MODO MULTIJUGADOR — ONLINE"**.
  Al tocarlo avisa que necesita internet y **conecta el juego LOCAL** al
  servidor global `wss://backrooms-mp.onrender.com` por WebSocket (el juego
  sigue saliendo 100% del APK; solo el chat y la sincronización usan la red).
  Después del aviso, te deja en la pestaña **MODO MULTIJUGADOR** para crear o
  unirte a una sala.
- La dirección queda recordada: la próxima vez el juego se conecta solo.
- La pestaña "MODO MULTIJUGADOR" también acepta cualquier servidor `wss://`
  propio (botón CONECTAR A ESTE SERVIDOR).
- Si no hay conexión, la pestaña muestra "CONEXIÓN PERDIDA" y reintenta sola.

### Cómo funciona la sincronización (resumen técnico)

- **Host autoritativo de enemigos** = el **admin** de la sala. Si el admin se
  desconecta, el servidor transfiere el rol y el nuevo admin pasa a simular.
  Si el host está en pausa o en el menú, las entidades se congelan para todos
  (compatibilidad: >3 s sin datos → cada cliente simula lo suyo).
- **Semilla de esquirlas**: la genera el servidor por sala; los clientes usan
  un PRNG determinista (mismo layout para todos). Se renueva al pasar al
  nivel 2.
- **Protocolo**: `chat` · `shard` (con deduplicación y corrección) · `ent`
  (solo admin) · `kill` (solo admin) · `win2` (grieta grupal). El servidor
  valida identidad/token en cada mensaje; jamás confía en campos del cliente.

## Cómo actualizar el juego

- **Solo HTML**: reemplazá los archivos en `assets/` manteniendo los enlaces a
  `./vendor/...` (mirá cualquier nivel actual como referencia).
- **Nivel nuevo**: copialo a `assets/` y asegurate de que sus dependencias
  estén en `vendor/` (three en la versión que use, fuentes, modelos, sonidos).

## Detalle técnico

- **WebView a pantalla completa**, inmersivo permanente, pantalla siempre
  encendida, rotación sin reinicio de partida, teclado ajustable para el chat
  y los inputs del multiplayer, doble ATRÁS para salir.
- **Origen virtual** `https://santyxdddgt.github.io/backrooms/` vía
  `WebViewAssetLoader` (handler local-first): origen seguro https para
  módulos ES/importmap, WebGL, WebAudio, localStorage unificado entre niveles
  y WebSocket. `ON_PAGES` da true → navegación relativa entre niveles,
  interceptada y servida desde el APK.
- **Navegación de niveles con sondeo**: cada transición (grieta, hub) verifica
  primero si el propio host sirve el archivo y usa URL relativa; solo cae al
  dominio absoluto como fallback (el WebView lo intercepta igual).
- **Hosts permitidos en el WebView**: el origen virtual del juego y
  `backrooms-mp.onrender.com`. Cualquier otro link cae al navegador externo.
- **Permisos**: `INTERNET` + `ACCESS_NETWORK_STATE` (solo para multiplayer;
  el single-player no genera tráfico).
- Recreación automática del WebView si muere el renderizador WebGL.

## Firma

- Debug y release firman con la keystore de debug autogenerada.
- Para Play Store: generá tu keystore con `keytool` y reemplazá el
  `signingConfig` en `app/build.gradle.kts`.

## Estructura del proyecto

```
BACKROOMS/
├── settings.gradle.kts · build.gradle.kts · gradle.properties
├── gradlew / gradlew.bat · gradle/wrapper/        (Gradle 8.11.1)
├── .github/workflows/android.yml                  (CI: arma el APK en GitHub)
└── app/
    ├── build.gradle.kts      AGP 8.7.3 · Kotlin 2.0.21 · minSdk 24 · target 35
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/           ← juego completo + vendor (ver arriba)
        ├── java/com/backrooms/game/MainActivity.kt
        └── res/              ícono pasillo Nivel 0 (adaptivo + legacy), theme negro
```
