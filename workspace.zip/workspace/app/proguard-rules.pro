# Sin minificación (isMinifyEnabled = false): no se necesitan reglas.
# Si activás R8 en release, conservá androidx.webkit:
# -keep class androidx.webkit.** { *; }
