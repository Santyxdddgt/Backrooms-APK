package com.backrooms.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.MimeTypeMap
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.IOException

/**
 * BACKROOMS — contenedor nativo del juego.
 *
 * TODOS los niveles corren bajo el mismo origen que la versión web del juego:
 * https://santyxdddgt.github.io/backrooms/
 *
 * Por qué este origen y no un dominio interno (appassets.androidplatform.net):
 *  - El juego navega entre niveles con `window.location` hacia GitHub Pages
 *    (level2.html, the-hub.html…). Al virtualizar ESE dominio, la navegación
 *    se intercepta y se sirve desde el APK sin abrir el navegador.
 *  - `ON_PAGES` (hostname === 'santyxdddgt.github.io') da true → el juego usa
 *    rutas relativas entre niveles, que también se interceptan.
 *  - localStorage queda UNIFICADO entre niveles servidos desde el APK y
 *    niveles cargados de la web real (mismo origen).
 *
 * Local-first: si un archivo existe en assets/ se sirve desde el APK; si falta
 * (p. ej. un nivel todavía no incluido) el WebView lo carga de la web real,
 * siempre DENTRO de la app. three.js, fuentes, .glb y .mp3 siguen saliendo
 * por red normalmente.
 */
class MainActivity : Activity() {

    companion object {
        private const val TAG = "BackroomsWeb"
        private const val GAME_HOST = "santyxdddgt.github.io"
        private const val GAME_BASE_PATH = "/backrooms/"
        private const val GAME_URL = "https://$GAME_HOST${GAME_BASE_PATH}index.html"

        // Servidor multijugador global: es la ÚNICA parte online de la app.
        // Sirve la versión online del juego + WebSocket, y corre DENTRO del
        // WebView (nunca en el navegador externo).
        private const val MP_HOST = "backrooms-mp.onrender.com"
        private const val EXIT_GRACE_MS = 2500L
    }

    private lateinit var root: FrameLayout
    private var webView: WebView? = null
    private var backPressedAt = 0L

    // Vista del elemento fullscreen (botón ⛶ del juego).
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val assetLoader: WebViewAssetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(GAME_HOST)
            .addPathHandler(GAME_BASE_PATH, LocalFirstAssetsHandler(applicationContext))
            .build()
    }

    /**
     * Sirve los archivos del juego desde el APK cuando existen en assets/.
     * Si falta uno devuelve null → WebViewAssetLoader devuelve null → el
     * WebView lo descarga de la web real, dentro de la app.
     */
    private class LocalFirstAssetsHandler(
        private val ctx: Context
    ) : WebViewAssetLoader.PathHandler {

        override fun handle(path: String): WebResourceResponse? {
            val assetPath = path.trimStart('/')
            return serve(assetPath.ifEmpty { "index.html" })
        }

        private fun serve(assetPath: String): WebResourceResponse? = try {
            val stream = ctx.assets.open(assetPath)
            val mime = mimeFor(assetPath)
            val encoding = if (isTextual(mime)) "utf-8" else null
            WebResourceResponse(mime, encoding, stream)
        } catch (_: IOException) {
            null // no está en el APK → que lo cargue de la web
        }

        private fun isTextual(mime: String): Boolean = mime.startsWith("text/") ||
                mime.contains("javascript") || mime.contains("json") ||
                mime.contains("svg")

        private fun mimeFor(path: String): String {
            val ext = path.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "html", "htm" -> "text/html"
                "js", "mjs" -> "text/javascript"
                "css" -> "text/css"
                "json" -> "application/json"
                "glb" -> "model/gltf-binary"
                "gltf" -> "model/gltf+json"
                "mp3" -> "audio/mpeg"
                "svg" -> "image/svg+xml"
                "woff2" -> "font/woff2"
                else -> MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Que la pantalla no se apague durante la partida.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Edge-to-edge: el juego ocupa el 100% de la pantalla.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setBackgroundDrawableResource(android.R.color.black)
        if (Build.VERSION.SDK_INT >= 27) {
            // Dibujar bajo el notch en horizontal.
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)

        // Con barras ocultas el juego es fullscreen; cuando aparece el TECLADO
        // (nombre de sala multijugador, URL del servidor...) el contenedor se
        // encoge para que los inputs no queden tapados.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            v.setPadding(0, 0, 0, maxOf(ime, nav))
            insets
        }

        setupWebView()
        hideSystemBars()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        wv.setBackgroundColor(Color.BLACK)
        wv.overScrollMode = WebView.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true                       // localStorage: progreso, stats, config MP
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false        // sonidos del juego tras noclip
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_DEFAULT            // cachea el CDN para arranques más rápidos
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW  // servidores ws:// de prueba
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100                                  // ignora la escala de fuente del sistema
        }

        wv.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // El juego y TODOS sus niveles viven en el origen virtual →
                // se quedan dentro del WebView (se sirvan del APK o de la web).
                if (request.url.host == GAME_HOST) return false
                // El servidor multijugador online también corre DENTRO de la
                // app (botón MODO MULTIJUGADOR del menú principal).
                if (request.url.host == MP_HOST) return false
                // Cualquier otro enlace se abre en el navegador.
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                } catch (_: Exception) {
                    true
                }
            }

            override fun onRenderProcessGone(
                view: WebView,
                detail: RenderProcessGoneDetail
            ): Boolean {
                // Si el renderizador WebGL muere (GPU), recreamos el WebView
                // en vez de matar la app.
                Log.e(TAG, "Render process gone (crash=${detail.didCrash()}); recreando WebView")
                exitCustomViewQuietly()
                root.removeAllViews()
                view.destroy()
                webView = null
                setupWebView()
                return true
            }

            // ===== Sin internet (modo multijugador) =====
            // Si falla la página principal (p. ej. sin red al entrar al
            // servidor online) mostramos una página de error local con
            // botones REINTENTAR / VOLVER AL JUEGO LOCAL.
            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (!request.isForMainFrame) return
                val desc = error.description?.toString() ?: ""
                if (desc.contains("ERR_ABORTED", ignoreCase = true)) return
                val failed = request.url.toString()
                Log.e(TAG, "Error de red ($desc) en $failed")
                val safe = Uri.encode(failed)
                view.loadUrl("https://$GAME_HOST${GAME_BASE_PATH}vendor/error.html?url=$safe")
            }
        }

        wv.webChromeClient = object : WebChromeClient() {

            override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                if (msg.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, "${msg.message()} — ${msg.sourceId()}:${msg.lineNumber()}")
                }
                return true
            }

            // ===== Fullscreen API del juego (botón ⛶) =====
            // En WebView, element.requestFullscreen() se canaliza por estos
            // callbacks: mostramos la vista del elemento cubriendo la pantalla.
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                root.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                hideSystemBars()
            }

            override fun onHideCustomView() {
                exitCustomViewQuietly()
            }
        }

        root.addView(wv)
        webView = wv
        wv.loadUrl(GAME_URL)
    }

    private fun exitCustomViewQuietly() {
        customView?.let { root.removeView(it) }
        customView = null
        try {
            customViewCallback?.onCustomViewHidden()
        } catch (_: Exception) {
        }
        customViewCallback = null
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Inmersivo permanente: si el usuario desliza para mostrar las barras,
        // se vuelven a ocultar al recuperar el foco.
        if (hasFocus) hideSystemBars()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // 1) Si el WebView tiene historial (p. ej. volvés del servidor online
        //    al juego local, o del Hub al Nivel 0), ATRÁS navega hacia atrás.
        if (webView?.canGoBack() == true) {
            webView?.goBack()
            return
        }
        // 2) Doble ATRÁS para salir, como en cualquier juego: evita cerrar la
        //    partida por accidente en plena persecución.
        val now = System.currentTimeMillis()
        if (now - backPressedAt < EXIT_GRACE_MS) {
            super.onBackPressed()
        } else {
            backPressedAt = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        // Pausa JS/timers/RAF del juego mientras está en segundo plano.
        webView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onDestroy() {
        root.removeAllViews()
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
